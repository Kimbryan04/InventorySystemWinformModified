﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace InventoryManagementSystemTest
{
    public partial class CategoryModuleForm : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\itdep\OneDrive\Documents\dbMS.mdf;Integrated Security=True;Connect Timeout=30");
        SqlCommand cm = new SqlCommand();

        public CategoryModuleForm()
        {
            InitializeComponent();
        }

        // Close the form
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        // Save button click event with validation
        private void btnsave_Click(object sender, EventArgs e)
        {
            // Validation for empty field
            if (string.IsNullOrEmpty(txtcatname.Text))
            {
                MessageBox.Show("Please enter a category name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Exit the function if validation fails
            }

            // Proceed with saving the category if validation passes
            try
            {
                if (MessageBox.Show("Are you sure you want to save this category?", "Saving Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cm = new SqlCommand("INSERT INTO tbCategory(name) VALUES(@name)", con);
                    cm.Parameters.AddWithValue("@name", txtcatname.Text);
                    con.Open();
                    cm.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Category has been successfully saved.");
                    Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Method to clear the form after successful save
        public void Clear()
        {
            txtcatname.Clear();
        }

        // Update button click event with validation
        private void btnupdate_Click(object sender, EventArgs e)
        {
            // Validation for empty field
            if (string.IsNullOrEmpty(txtcatname.Text))
            {
                MessageBox.Show("Please enter a category name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Exit the function if validation fails
            }

            // Proceed with updating the category if validation passes
            try
            {
                if (MessageBox.Show("Are you sure you want to update this category?", "Update Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cm = new SqlCommand("UPDATE tbCategory SET name = @name WHERE category_Id = @categoryId", con);
                    cm.Parameters.AddWithValue("@name", txtcatname.Text);
                    cm.Parameters.AddWithValue("@categoryId", lblCatld.Text); // Assuming lblCatld contains the category ID
                    con.Open();
                    cm.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Category has been successfully updated!");
                    this.Dispose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
