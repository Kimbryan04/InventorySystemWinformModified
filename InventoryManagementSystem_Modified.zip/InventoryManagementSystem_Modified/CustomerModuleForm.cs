﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace InventoryManagementSystemTest
{
    public partial class CustomerModuleForm : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\itdep\OneDrive\Documents\dbMS.mdf;Integrated Security=True;Connect Timeout=30");
        SqlCommand cm = new SqlCommand();

        public CustomerModuleForm()
        {
            InitializeComponent();
        }

        // Save button click event with validation
        private void btnsave_Click(object sender, EventArgs e)
        {
            // Validation for empty fields
            if (string.IsNullOrEmpty(txtcname.Text) || string.IsNullOrEmpty(txtcphone.Text))
            {
                MessageBox.Show("Please fill in all fields before saving.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Exit the function if validation fails
            }

            // Validate if the phone number contains only numbers
            if (!long.TryParse(txtcphone.Text, out long phoneNumber))
            {
                MessageBox.Show("Please enter a valid phone number.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Proceed with saving the customer if all validations pass
            try
            {
                if (MessageBox.Show("Are you sure you want to save this customer?", "Saving Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cm = new SqlCommand("INSERT INTO tbCustomer(cname, cphone) VALUES(@cname, @cphone)", con);
                    cm.Parameters.AddWithValue("@cname", txtcname.Text);
                    cm.Parameters.AddWithValue("@cphone", txtcphone.Text);
                    con.Open();
                    cm.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Customer has been successfully saved.");
                    Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Method to clear the form after successful save
        public void Clear()
        {
            txtcname.Clear();
            txtcphone.Clear();
        }

        // Delete button click event to reset the form
        private void btndelete_Click(object sender, EventArgs e)
        {
            Clear();
            btnsave.Enabled = true;
            btnupdate.Enabled = false;
        }

        // Close the form
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        // Update button click event with validation
        private void btnupdate_Click(object sender, EventArgs e)
        {
            // Validation for empty fields
            if (string.IsNullOrEmpty(txtcname.Text) || string.IsNullOrEmpty(txtcphone.Text))
            {
                MessageBox.Show("Please fill in all fields before updating.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Exit the function if validation fails
            }

            // Validate if the phone number contains only numbers
            if (!long.TryParse(txtcphone.Text, out long phoneNumber))
            {
                MessageBox.Show("Please enter a valid phone number.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Proceed with updating the customer if all validations pass
            try
            {
                if (MessageBox.Show("Are you sure you want to update this customer?", "Update Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cm = new SqlCommand("UPDATE tbCustomer SET cname = @cname, cphone = @cphone WHERE cId LIKE @cId", con);
                    cm.Parameters.AddWithValue("@cname", txtcname.Text);
                    cm.Parameters.AddWithValue("@cphone", txtcphone.Text);
                    cm.Parameters.AddWithValue("@cId", lblCld.Text);  // Assuming lblCld contains the customer ID
                    con.Open();
                    cm.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Customer has been successfully updated!");
                    this.Dispose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
