﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace InventoryManagementSystemTest
{
    public partial class ProductModuleForm : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\itdep\OneDrive\Documents\dbMS.mdf;Integrated Security=True;Connect Timeout=30");
        SqlCommand cm = new SqlCommand();
        SqlDataReader dr;

        public ProductModuleForm()
        {
            InitializeComponent();
            LoadCategory();
        }

        // Method to load categories into the combo box
        public void LoadCategory()
        {
            cbcat.Items.Clear();
            cm = new SqlCommand("SELECT name FROM tbCategory", con);
            con.Open();
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                cbcat.Items.Add(dr[0].ToString());
            }
            dr.Close();
            con.Close();
        }

        // Close the form
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        // Save button click event with validation
        private void btnsave_Click(object sender, EventArgs e)
        {
            // Validation for empty fields
            if (string.IsNullOrEmpty(txtpname.Text) || string.IsNullOrEmpty(txtqty.Text) || string.IsNullOrEmpty(txtprice.Text) || string.IsNullOrEmpty(txtdesc.Text) || string.IsNullOrEmpty(cbcat.Text))
            {
                MessageBox.Show("Please fill in all fields before saving.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Exit the function if validation fails
            }

            // Validate if qty and price are valid integers
            if (!int.TryParse(txtqty.Text, out int qty) || qty <= 0)
            {
                MessageBox.Show("Please enter a valid quantity (positive number).", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtprice.Text, out int price) || price <= 0)
            {
                MessageBox.Show("Please enter a valid price (positive number).", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Proceed with saving the product if all validations pass
            try
            {
                if (MessageBox.Show("Are you sure you want to save this product?", "Saving Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cm = new SqlCommand("INSERT INTO tbproduct(pname, qty, price, [desc], pcategory) VALUES(@pname, @qty, @price, @desc, @pcategory)", con);
                    cm.Parameters.AddWithValue("@pname", txtpname.Text);
                    cm.Parameters.AddWithValue("@qty", qty);
                    cm.Parameters.AddWithValue("@price", price);
                    cm.Parameters.AddWithValue("@desc", txtdesc.Text);
                    cm.Parameters.AddWithValue("@pcategory", cbcat.Text);
                    con.Open();
                    cm.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Product has been successfully saved.");
                    Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Method to clear the form after successful save
        public void Clear()
        {
            txtpname.Clear();
            txtqty.Clear();
            txtprice.Clear();
            txtdesc.Clear();
            cbcat.Text = "";
        }

        // Update button click event with validation
        private void btnupdate_Click(object sender, EventArgs e)
        {
            // Validation for empty fields
            if (string.IsNullOrEmpty(txtpname.Text) || string.IsNullOrEmpty(txtqty.Text) || string.IsNullOrEmpty(txtprice.Text) || string.IsNullOrEmpty(txtdesc.Text) || string.IsNullOrEmpty(cbcat.Text))
            {
                MessageBox.Show("Please fill in all fields before updating.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Exit the function if validation fails
            }

            // Validate if qty and price are valid integers
            if (!int.TryParse(txtqty.Text, out int qty) || qty <= 0)
            {
                MessageBox.Show("Please enter a valid quantity (positive number).", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtprice.Text, out int price) || price <= 0)
            {
                MessageBox.Show("Please enter a valid price (positive number).", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Proceed with updating the product if all validations pass
            try
            {
                if (MessageBox.Show("Are you sure you want to update this product?", "Update Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cm = new SqlCommand("UPDATE tbProduct SET pname = @pname, qty = @qty, price = @price, [desc] = @desc, pcategory = @pcategory WHERE product_id = @product_id", con);
                    cm.Parameters.AddWithValue("@pname", txtpname.Text);
                    cm.Parameters.AddWithValue("@qty", qty);
                    cm.Parameters.AddWithValue("@price", price);
                    cm.Parameters.AddWithValue("@desc", txtdesc.Text);
                    cm.Parameters.AddWithValue("@pcategory", cbcat.Text);
                    cm.Parameters.AddWithValue("@product_id", lblPId.Text); // Assuming lblPId contains the product ID
                    con.Open();
                    cm.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Product has been successfully updated!");
                    this.Dispose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Clear button to reset the form
        private void btndelete_Click(object sender, EventArgs e)
        {
            Clear();
        }
    }
}
