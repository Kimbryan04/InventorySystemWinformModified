﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace InventoryManagementSystemTest
{
    public partial class main : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\itdep\OneDrive\Documents\dbMS.mdf;Integrated Security=True;Connect Timeout=30");
        SqlCommand cm = new SqlCommand();
        SqlDataReader dr;
        public main()
        {
            InitializeComponent();
            LoadOrder();
            LoadPieChart();
        }

        private Form activeForm = null;
        private void OpenChildForm(Form childForm)
        {
            if (activeForm != null) 
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;  
            childForm.Dock = DockStyle.Fill;   
            panelMain.Controls.Add(childForm);
            panelMain.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();

        }

        public void LoadOrder()
        {
            int i = 0;
            dvgorder.Rows.Clear();
            cm = new SqlCommand("SELECT odate, cid, qty, price, total FROM tbOrder", con);
            con.Open();
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dvgorder.Rows.Add(i, dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString());
            }
            dr.Close();
            con.Close();
        }

        private void main_Load(object sender, EventArgs e)
        {
            // Load the analytics data on form load
            LoadAnalyticsData();
        }

        private void LoadAnalyticsData()
        {
            double totalSales = 0;
            int totalOrders = 0;
            int totalProducts = 0;
            int totalCustomers = 0;

            try
            {
                // Open connection once
                con.Open();

                // Fetch Total Sales
                using (cm = new SqlCommand("SELECT SUM(total) FROM tbOrder", con))
                {
                    using (dr = cm.ExecuteReader())
                    {
                        if (dr.Read() && dr[0] != DBNull.Value)
                        {
                            totalSales = Convert.ToDouble(dr[0]);
                        }
                    }
                }

                // Fetch Total Orders
                using (cm = new SqlCommand("SELECT COUNT(orderid) FROM tbOrder", con))
                {
                    using (dr = cm.ExecuteReader())
                    {
                        if (dr.Read() && dr[0] != DBNull.Value)
                        {
                            totalOrders = Convert.ToInt32(dr[0]);
                        }
                    }
                }

                // Fetch Total Products
                using (cm = new SqlCommand("SELECT COUNT(product_Id) FROM tbProduct", con))
                {
                    using (dr = cm.ExecuteReader())
                    {
                        if (dr.Read() && dr[0] != DBNull.Value)
                        {
                            totalProducts = Convert.ToInt32(dr[0]);
                        }
                    }
                }

                // Fetch Total Customers
                using (cm = new SqlCommand("SELECT COUNT(cid) FROM tbCustomer", con))
                {
                    using (dr = cm.ExecuteReader())
                    {
                        if (dr.Read() && dr[0] != DBNull.Value)
                        {
                            totalCustomers = Convert.ToInt32(dr[0]);
                        }
                    }
                }

                // Close the connection
                con.Close();

                // Display the data on the labels
                lblTotalSales.Text = "Total Sales" + "\n" + "P" + totalSales.ToString("N2");
                lblTotalOrders.Text = "Total Orders" + "\n" + totalOrders.ToString();
                lblTotalProducts.Text = "Total Products" + "\n" + totalProducts.ToString();
                lblTotalCustomers.Text = "Total Customers" + "\n" + totalCustomers.ToString();

                // Center-align both the text and the value
                lblTotalSales.TextAlign = ContentAlignment.MiddleCenter;
                lblTotalOrders.TextAlign = ContentAlignment.MiddleCenter;
                lblTotalProducts.TextAlign = ContentAlignment.MiddleCenter;
                lblTotalCustomers.TextAlign = ContentAlignment.MiddleCenter;

                // Display data on the chart
                DisplayChartData(totalSales, totalOrders, totalProducts, totalCustomers);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }
        }

        private void DisplayChartData(double totalSales, int totalOrders, int totalProducts, int totalCustomers)
        {
            // Clear previous data in the chart
            chart1.Series.Clear();
            chart2.Series.Clear();

            // Create a new series for the chart
            Series series = new Series("Analytics")
            {
                ChartType = SeriesChartType.Column,  // Column chart to display the data
                IsValueShownAsLabel = true,         // Show values on top of bars
                BorderWidth = 2
            };

            // Add data points for each metric
            series.Points.AddXY("Sales", totalSales);
           

            // Add the series to the chart
            chart1.Series.Add(series);

            

            // Create a new series for the chart
            Series series2 = new Series("Analytics")
            {
                ChartType = SeriesChartType.Column,  // Column chart to display the data
                IsValueShownAsLabel = true,         // Show values on top of bars
                BorderWidth = 2
            };

            series2.Points.AddXY("Orders", totalOrders);
            series2.Points.AddXY("Products", totalProducts);
            series2.Points.AddXY("Customers", totalCustomers);

            chart2.Series.Add(series2);
        }

        private void LoadPieChart()
        {
            // SQL query to fetch product counts per category from tbProduct
            string query = "SELECT pcategory, COUNT(DISTINCT product_id) AS productCount " +
                           "FROM tbProduct " +
                           "GROUP BY pcategory"; // Group by category to count products per category

            try
            {
                // Open the database connection
                con.Open();
                cm = new SqlCommand(query, con);
                dr = cm.ExecuteReader();

                // Clear any existing data in the chart
                chart3.Series[0].Points.Clear();

                // Iterate through the result set and add data to the pie chart
                while (dr.Read())
                {
                    // Get the category and product count from the query result
                    string category = dr["pcategory"].ToString();
                    int productCount = Convert.ToInt32(dr["productCount"]);

                    // Add the data to the pie chart: category as the label, and product count as the value
                    chart3.Series[0].Points.AddXY(category, productCount);
                }

                // Close the data reader and the connection
                dr.Close();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        

        private void btnuser_Click(object sender, EventArgs e)
        {
            OpenChildForm(new UserForm());
        }

        private void btncustomer_Click(object sender, EventArgs e)
        {
            OpenChildForm(new CustomerForm());
        }

        private void btncategory_Click(object sender, EventArgs e)
        {
            OpenChildForm(new dvgcategory());
        }

        private void btnproduct_Click(object sender, EventArgs e)
        {
            OpenChildForm(new ProductForm());
        }

        private void btnorders_Click(object sender, EventArgs e)
        {
            OpenChildForm(new OrderForm());
        }

        private void label1_Click_1(object sender, EventArgs e)
        {
            main mainForm = new main();

            
            mainForm.Show();

            
            this.Hide();
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lblTotalSales_Click(object sender, EventArgs e)
        {

        }

        private void lblTotalOrders_Click(object sender, EventArgs e)
        {

        }

        private void lblTotalCustomers_Click(object sender, EventArgs e)
        {

        }

        private void lblTotalProducts_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
