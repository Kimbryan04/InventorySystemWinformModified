﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace InventoryManagementSystemTest
{
    public partial class changepassform : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\itdep\OneDrive\Documents\dbMS.mdf;Integrated Security=True;Connect Timeout=30");
        SqlCommand cm = new SqlCommand();
        SqlDataReader dr;
        public changepassform()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnChangePassword_Click(object sender, EventArgs e)
        {
            string username =  txtUsername.Text;
            string oldPassword = txtOldPassword.Text;
            string newPassword = txtNewPassword.Text;

            // Input validation
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(oldPassword) || string.IsNullOrEmpty(newPassword))
            {
                MessageBox.Show("Please fill in all fields!", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Check if the old password is correct
            try
            {
                cm = new SqlCommand("SELECT * FROM tbUser WHERE username=@username AND password=@oldPassword", con);
                cm.Parameters.AddWithValue("@username", username);  // Get username from the textbox
                cm.Parameters.AddWithValue("@oldPassword", oldPassword);  // Get old password from the textbox
                con.Open();
                dr = cm.ExecuteReader();

                if (dr.HasRows)  // If the user exists with the correct old password
                {
                    // Close the reader before executing the update query
                    con.Close();

                    // Now, update the password in the database with the new password
                    cm = new SqlCommand("UPDATE tbUser SET password=@newPassword WHERE username=@username", con);
                    cm.Parameters.AddWithValue("@username", username);  // Get username from the textbox
                    cm.Parameters.AddWithValue("@newPassword", newPassword);  // Get new password from the textbox
                    con.Open();
                    cm.ExecuteNonQuery();
                    con.Close();

                    MessageBox.Show("Password changed successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();  // Close the form after the password is changed
                }
                else
                {
                    MessageBox.Show("The old password is incorrect!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {
            txtOldPassword.Clear();
            txtUsername.Clear();
            txtNewPassword.Clear();
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == false)
            {
                txtNewPassword.UseSystemPasswordChar = true;
                txtOldPassword.UseSystemPasswordChar = true;
            }
            else
            {
                txtNewPassword.UseSystemPasswordChar = false;
                txtOldPassword.UseSystemPasswordChar = false;
            }
                
        }
    }
}
